function res = EfficientFrontier(varargin)
%EfficientFrontier_constr Constrained efficient frontier
  % INPUTS
  % r: expected returns of the assets, table
  % S: covariance matrix of the asset returns, table
  % N: number of portfolios, default 1000
  % maxRet : maximum portfolio return to be calculated, default 1.6
  % NOSHORT: if true no short selling allowed, default true
  % BTC: if false BTC will be excluded from the calculations, default true
  % OUTPUT
  % table(return,volatility,allocations) N x nAssets
  
% Default parameters
defaultN = 1000;
defaultMaxRet = 1.6;
defaultNOSHORT = true;
defaultBTC = true;

p = inputParser;
addRequired(p,'r',@istable);
addRequired(p,'S',@istable);
addParameter(p,'NOSHORT',defaultNOSHORT,@islogical);
addParameter(p,'N',defaultN,@isint);
addParameter(p,'maxRet',defaultMaxRet,@isreal);
addParameter(p,'BTC',defaultBTC,@islogical);
parse(p,varargin{:});
BTC = p.Results.BTC;
NOSHORT = p.Results.NOSHORT;
r = p.Results.r;
S = p.Results.S;
N = p.Results.N;
maxRet = p.Results.maxRet;
names = r.Properties.VariableNames;

%%%%
if ~BTC
    if any(strcmp(names,'BTC')) % If BTC is in the data
        r = removevars(r,'BTC');
        S = removevars(S,'BTC'); % Remove BTC column
        S('BTC',:) = []; % Remove BTC row
        names = r.Properties.VariableNames;
    end
end

nAssets = width(r);
rr = r.Variables;
SS = S.Variables;


if NOSHORT
    noShort = zeros(nAssets,1);
else
    noShort = [];
end



% Constraint on weights: sum(w)=1
Aeq = [rr; ones(1,nAssets)];
beq = [0, 1];

%%%% Global minumum
options = optimoptions('quadprog','Display','off');
[minW,minVol] = quadprog(2*SS,zeros(1,nAssets),[],[],ones(1,nAssets),1,noShort,[],[],options);
minVol = sqrt(minVol);
minRet = rr*minW;

ret = linspace(minRet,maxRet,N+1); % Optimizer input
vol = zeros(1,length(ret)); % Optimizer output
allocation = zeros(nAssets,length(ret)); % Optimizer output


i = N+1;
while i
    beq(1) = ret(i);
    [allocation(:,i), vol(i),exitFlag] = quadprog(2*SS, zeros(1,nAssets),[],[], Aeq, beq,noShort,[],[],options);
    if exitFlag == -2 % if error in optimization
        ret = linspace(minRet,ret(i-1),N+1); % reduce input
    else
        vol(i) = sqrt(vol(i));
        i = i-1;
    end
end


vol = vol';
ret = ret';
allocation = allocation';
allocation = array2table(allocation,'VariableNames',names);

res = table(vol,ret,allocation);

end