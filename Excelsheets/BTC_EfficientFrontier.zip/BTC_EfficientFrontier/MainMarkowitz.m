%% Set Up
clc
clear all; 
ImportData % Import data from file Data.xlsx and save in the table Data

cpdata = Data; % Copied Data to be manipulated
cpdata = flip(cpdata); % Reorder dates from older to newer
cpdata = table2timetable(cpdata);  % Create timetable of prices
names = cpdata.Properties.VariableNames; % Save asset names

%% ***** PERCENTAGE RETURNS ****** - WHY NOT LOGARITHM??
returns = tick2ret(cpdata); % PERCENTAGE RETURNS
% returns = tick2ret(cpdata,'Method','Continuous'); % LOG RETURNS
r = mean(returns.Variables+1).^255; % Array of mean annual returns
r = array2table(r,'VariableNames',names); % Table with asset names
S = cov(returns.Variables)*255; % Covariance matrix
S = array2table(S,'VariableNames',names,'RowNames',names); % Table with asset names

%% Efficient Frontiers
res1 = EfficientFrontier(r,S,'NOSHORT',true, 'BTC',true,'maxRet', 1.6);  % No Short selling,    BTC in the portfolio
res2 = EfficientFrontier(r,S,'NOSHORT',false,'BTC',true);  %    Short selling,    BTC in the portfolio
res3 = EfficientFrontier(r,S,'NOSHORT',true, 'BTC',false); % No Short selling, no BTC in the portfolio
res4 = EfficientFrontier(r,S,'NOSHORT',false,'BTC',false); %    Short selling, no BTC in the portfolio

%% Plot Frontiers
plot(res1.vol*100,res1.ret*100-100)
hold on
plot(res2.vol*100,res2.ret*100-100)
hold on
plot(res3.vol*100,res3.ret*100-100)
hold on
plot(res4.vol*100,res4.ret*100-100)
legend('No Short selling, BTC in the portfolio',...
          'Short selling, BTC in the portfolio',...
       'No Short selling, no BTC in the portfolio',...
          'Short selling, no BTC in the portfolio',...
        'location','northwest');
xlim([min([res1.vol; res2.vol; res3.vol; res4.vol])*100-0.05 10]);
grid on
xtickformat('percentage')
ytickformat('percentage')
xlabel('Volatility')
ylabel('Returns')
title('Efficient Frontier')

%% linear allocation on volatility for BTC & NOSHORT
linVol = linspace(min(res1.vol),max(res1.vol),length(res1.vol)/10);
mm = (linVol-res1.vol)>0;
index = zeros(1,length(linVol));

for i = 1:length(linVol)
    index(i) = find(mm(:,i)==0,1,'first');
end

linRet = res1.ret(index);
linW = res1.allocation(index,:);


%% Plot allocation linear on volatility
% plot weights area
figure;
h = area(linVol'*100,linW.Variables*100);
xlim([min(linVol)*100 max(linVol)*100])
ylim([0 100])
xlabel('Volatility')
ylabel('Weights')
title('Portfolio Allocation')
xtickformat('percentage')
ytickformat('percentage')
% color each area using the map jet
colors = jet;
for i=1:length(names)
    h(i).FaceColor = colors(floor(64/length(names))*i,:);
end
% % set legend
legend(names,'location','northeast')